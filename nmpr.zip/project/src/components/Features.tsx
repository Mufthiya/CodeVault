import React from 'react';
import { 
  ShieldAlert, 
  Brain, 
  Bell, 
  Lock, 
  Clock, 
  Zap
} from 'lucide-react';
import { FeatureItem } from '../types';

const features: FeatureItem[] = [
  {
    title: 'Real-Time Monitoring',
    description: 'Continuous transaction monitoring with instant alerts when suspicious activity is detected.',
    icon: Clock
  },
  {
    title: 'AI-Powered Detection',
    description: 'Advanced machine learning algorithms that adapt to evolving fraud patterns.',
    icon: Brain
  },
  {
    title: 'Instant Alerts',
    description: 'Immediate notifications for suspicious transactions requiring your attention.',
    icon: Bell
  },
  {
    title: 'Bank-Level Security',
    description: 'Enterprise-grade encryption keeping your financial data safe and secure.',
    icon: Lock
  },
  {
    title: 'Fast Implementation',
    description: 'Quick and seamless integration with your existing accounts and cards.',
    icon: Zap
  },
  {
    title: 'Fraud Prevention',
    description: 'Proactive measures to stop fraudulent transactions before they occur.',
    icon: ShieldAlert
  }
];

const Features: React.FC = () => {
  return (
    <section id="features" className="section bg-gray-50">
      <div className="container-custom">
        <div className="max-w-3xl mx-auto text-center mb-16">
          <h2 className="mb-4 text-gray-900">How YOURGUARD Protects You</h2>
          <p className="text-xl text-gray-600">
            Our comprehensive security features work together to provide unmatched protection
            for all your financial transactions.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <div 
              key={index} 
              className="card group hover:border-primary-500 hover:border"
            >
              <div className="w-12 h-12 rounded-lg bg-primary-100 flex items-center justify-center mb-4 group-hover:bg-primary-500 transition-colors">
                <feature.icon size={24} className="text-primary-600 group-hover:text-white transition-colors" />
              </div>
              <h3 className="text-xl font-semibold mb-2">{feature.title}</h3>
              <p className="text-gray-600">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Features;