import React from 'react';
import { ShieldCheck, ArrowRight } from 'lucide-react';

const Hero: React.FC = () => {
  return (
    <section id="home" className="pt-28 pb-16 md:pt-32 md:pb-24">
      <div className="container-custom">
        <div className="max-w-4xl mx-auto text-center">
          <div className="inline-flex items-center px-4 py-2 bg-primary-100 rounded-full text-primary-800 mb-6">
            <ShieldCheck size={18} className="mr-2" />
            <span className="text-sm font-medium">AI-Powered Fraud Protection</span>
          </div>
          
          <h1 className="mb-6 font-bold tracking-tight text-gray-900">
            Protect Your Transactions With{' '}
            <span className="text-primary-600">Advanced AI</span> Fraud Detection
          </h1>
          
          <p className="text-xl text-gray-600 mb-8 max-w-3xl mx-auto">
            YOURGUARD uses cutting-edge artificial intelligence to detect and prevent credit card fraud before it happens, 
            keeping your finances secure around the clock.
          </p>
          
          <div className="flex flex-col sm:flex-row justify-center gap-4">
            <a href="#signup" className="btn-primary">
              Secure Your Account
              <ArrowRight size={18} className="ml-2" />
            </a>
            <a href="#features" className="btn-outline">
              Learn How It Works
            </a>
          </div>
          
          <div className="mt-12 pt-8 border-t border-gray-200">
            <p className="text-sm text-gray-500 mb-3">Trusted by individuals and businesses worldwide</p>
            <div className="flex flex-wrap justify-center gap-8">
              <div className="text-gray-400 font-semibold">VISA</div>
              <div className="text-gray-400 font-semibold">MASTERCARD</div>
              <div className="text-gray-400 font-semibold">AMERICAN EXPRESS</div>
              <div className="text-gray-400 font-semibold">DISCOVER</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;