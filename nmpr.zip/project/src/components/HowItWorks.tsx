import React from 'react';
import { CreditCard, ShieldCheck, AlertCircle, CheckCircle } from 'lucide-react';

const HowItWorks: React.FC = () => {
  return (
    <section id="how-it-works" className="section bg-white">
      <div className="container-custom">
        <div className="max-w-3xl mx-auto text-center mb-16">
          <h2 className="mb-4 text-gray-900">How YOURGUARD Works</h2>
          <p className="text-xl text-gray-600">
            Our AI-powered system works seamlessly in the background to keep your transactions secure
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-16 items-center">
          <div className="order-2 md:order-1">
            <div className="space-y-12">
              <div className="flex">
                <div className="flex-shrink-0 mt-1">
                  <div className="flex items-center justify-center w-8 h-8 rounded-full bg-primary-100 text-primary-600">
                    1
                  </div>
                </div>
                <div className="ml-4">
                  <h3 className="text-xl font-medium mb-2 text-gray-900">Connect Your Accounts</h3>
                  <p className="text-gray-600">
                    Securely link your credit cards and bank accounts to our system using bank-level encryption.
                  </p>
                </div>
              </div>

              <div className="flex">
                <div className="flex-shrink-0 mt-1">
                  <div className="flex items-center justify-center w-8 h-8 rounded-full bg-primary-100 text-primary-600">
                    2
                  </div>
                </div>
                <div className="ml-4">
                  <h3 className="text-xl font-medium mb-2 text-gray-900">Real-Time Monitoring</h3>
                  <p className="text-gray-600">
                    Our AI continuously monitors your transactions, analyzing patterns and detecting anomalies.
                  </p>
                </div>
              </div>

              <div className="flex">
                <div className="flex-shrink-0 mt-1">
                  <div className="flex items-center justify-center w-8 h-8 rounded-full bg-primary-100 text-primary-600">
                    3
                  </div>
                </div>
                <div className="ml-4">
                  <h3 className="text-xl font-medium mb-2 text-gray-900">Instant Alerts</h3>
                  <p className="text-gray-600">
                    Receive immediate notifications when suspicious activity is detected, allowing you to take action.
                  </p>
                </div>
              </div>

              <div className="flex">
                <div className="flex-shrink-0 mt-1">
                  <div className="flex items-center justify-center w-8 h-8 rounded-full bg-primary-100 text-primary-600">
                    4
                  </div>
                </div>
                <div className="ml-4">
                  <h3 className="text-xl font-medium mb-2 text-gray-900">Fraud Prevention</h3>
                  <p className="text-gray-600">
                    Automatically block suspicious transactions before they're processed, protecting your accounts.
                  </p>
                </div>
              </div>
            </div>
          </div>

          <div className="order-1 md:order-2">
            <div className="bg-gray-50 p-8 rounded-2xl shadow-card">
              <div className="space-y-6">
                <div className="flex items-center bg-white p-4 rounded-lg shadow-sm">
                  <CreditCard className="w-10 h-10 text-primary-600 mr-4" />
                  <div>
                    <h4 className="font-medium">New Transaction</h4>
                    <p className="text-sm text-gray-500">Coffee Shop - $4.50</p>
                  </div>
                  <CheckCircle className="w-6 h-6 text-green-500 ml-auto" />
                </div>

                <div className="flex items-center bg-white p-4 rounded-lg shadow-sm">
                  <CreditCard className="w-10 h-10 text-primary-600 mr-4" />
                  <div>
                    <h4 className="font-medium">New Transaction</h4>
                    <p className="text-sm text-gray-500">Online Store - $249.99</p>
                  </div>
                  <AlertCircle className="w-6 h-6 text-amber-500 ml-auto" />
                </div>

                <div className="bg-red-50 p-4 rounded-lg border border-red-100">
                  <div className="flex items-center">
                    <ShieldCheck className="w-10 h-10 text-red-600 mr-4" />
                    <div>
                      <h4 className="font-medium text-red-700">Fraud Detected!</h4>
                      <p className="text-sm text-red-600">Unusual Transaction - $1,599.00</p>
                      <p className="text-xs text-red-500 mt-1">Transaction blocked: Location mismatch</p>
                    </div>
                  </div>
                </div>

                <div className="bg-primary-50 p-4 rounded-lg">
                  <p className="text-sm text-primary-700 font-medium">
                    YOURGUARD's AI has saved customers over $2.4 million in potential fraud
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default HowItWorks;