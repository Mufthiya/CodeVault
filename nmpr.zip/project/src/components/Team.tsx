import React from 'react';
import { Mail, Phone, Github, Linkedin } from 'lucide-react';
import { TeamMember } from '../types';

const teamMembers: TeamMember[] = [
  {
    name: 'Sabitha E.S.',
    role: 'AI Engineer & Co-founder',
  },
  {
    name: 'Nishanth M',
    role: 'Security Specialist & Co-founder',
  },
  {
    name: 'Antony Sampres',
    role: 'Product Lead & Co-founder',
  },
];

const Team: React.FC = () => {
  return (
    <section id="team" className="section bg-gray-50">
      <div className="container-custom">
        <div className="max-w-3xl mx-auto text-center mb-16">
          <h2 className="mb-4 text-gray-900">The Team Behind YOURGUARD</h2>
          <p className="text-xl text-gray-600">
            Our expert team combines decades of experience in AI, cybersecurity, and financial technologies
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {teamMembers.map((member, index) => (
            <div key={index} className="card text-center hover:transform hover:scale-105">
              <div className="w-24 h-24 bg-gray-200 rounded-full mx-auto mb-4 flex items-center justify-center">
                <span className="text-3xl text-gray-500">{member.name.charAt(0)}</span>
              </div>
              <h3 className="text-xl font-semibold mb-1">{member.name}</h3>
              <p className="text-gray-600 mb-4">{member.role}</p>
              <div className="flex justify-center space-x-4">
                <a href="#" className="text-gray-500 hover:text-primary-600 transition-colors">
                  <Mail size={20} />
                </a>
                <a href="#" className="text-gray-500 hover:text-primary-600 transition-colors">
                  <Linkedin size={20} />
                </a>
                <a href="#" className="text-gray-500 hover:text-primary-600 transition-colors">
                  <Github size={20} />
                </a>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-16 bg-white rounded-xl p-8 shadow-card">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div>
              <h3 className="text-2xl font-semibold mb-4">Contact Us</h3>
              <p className="text-gray-600 mb-6">
                Have questions about our service? Need assistance with implementation? Our team is here to help.
              </p>
              <div className="space-y-4">
                <div className="flex items-center">
                  <Phone className="w-5 h-5 text-primary-600 mr-3" />
                  <a href="tel:+12345678" className="text-gray-700 hover:text-primary-600 transition-colors">
                    +12345678 or 9962243844
                  </a>
                </div>
                <div className="flex items-center">
                  <Mail className="w-5 h-5 text-primary-600 mr-3" />
                  <a href="mailto:Ckecfrauddetector@gmail.com" className="text-gray-700 hover:text-primary-600 transition-colors">
                    Ckecfrauddetector@gmail.com
                  </a>
                </div>
              </div>
            </div>
            <div>
              <h3 className="text-2xl font-semibold mb-4">Office Hours</h3>
              <p className="text-gray-600 mb-6">
                Our support team is available during the following hours:
              </p>
              <ul className="space-y-2 text-gray-700">
                <li>Monday - Friday: 9 AM - 8 PM EST</li>
                <li>Saturday: 10 AM - 6 PM EST</li>
                <li>Sunday: Closed</li>
              </ul>
              <p className="mt-4 text-gray-600">
                For urgent matters outside of business hours, please email us and we'll respond as soon as possible.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Team;