import React, { useState } from 'react';
import { useForm } from 'react-hook-form';
import { CheckCircle, AlertCircle } from 'lucide-react';
import { UserFormData } from '../types';

const UserForm: React.FC = () => {
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  const { 
    register, 
    handleSubmit, 
    formState: { errors } 
  } = useForm<UserFormData>();

  const onSubmit = (data: UserFormData) => {
    setIsSubmitting(true);
    
    // Simulate form submission
    setTimeout(() => {
      console.log('Form data:', data);
      setIsSubmitting(false);
      setIsSubmitted(true);
    }, 1500);
  };

  if (isSubmitted) {
    return (
      <div className="text-center p-8 bg-green-50 rounded-xl border border-green-100">
        <CheckCircle className="w-16 h-16 text-green-500 mx-auto mb-4" />
        <h3 className="text-2xl font-semibold mb-2">Thank You!</h3>
        <p className="text-gray-700 mb-4">
          Your information has been submitted successfully. Our team will review your details and contact you soon.
        </p>
        <button 
          onClick={() => setIsSubmitted(false)}
          className="btn-primary"
        >
          Submit Another Request
        </button>
      </div>
    );
  }

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div>
          <label htmlFor="fullName" className="label">Full Name</label>
          <input
            id="fullName"
            type="text"
            className={`input ${errors.fullName ? 'border-red-500' : ''}`}
            placeholder="Enter your full name"
            {...register('fullName', { required: 'Full name is required' })}
          />
          {errors.fullName && (
            <p className="error-message">
              <AlertCircle className="w-4 h-4 inline mr-1" />
              {errors.fullName.message}
            </p>
          )}
        </div>

        <div>
          <label htmlFor="email" className="label">Email Address</label>
          <input
            id="email"
            type="email"
            className={`input ${errors.email ? 'border-red-500' : ''}`}
            placeholder="Enter your email address"
            {...register('email', { 
              required: 'Email is required',
              pattern: {
                value: /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i,
                message: 'Invalid email address'
              }
            })}
          />
          {errors.email && (
            <p className="error-message">
              <AlertCircle className="w-4 h-4 inline mr-1" />
              {errors.email.message}
            </p>
          )}
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div>
          <label htmlFor="phone" className="label">Phone Number</label>
          <input
            id="phone"
            type="tel"
            className={`input ${errors.phone ? 'border-red-500' : ''}`}
            placeholder="Enter your phone number"
            {...register('phone', { 
              required: 'Phone number is required',
              pattern: {
                value: /^[\d\+\-\(\) ]{7,20}$/,
                message: 'Invalid phone number'
              }
            })}
          />
          {errors.phone && (
            <p className="error-message">
              <AlertCircle className="w-4 h-4 inline mr-1" />
              {errors.phone.message}
            </p>
          )}
        </div>

        <div>
          <label htmlFor="accountType" className="label">Account Type</label>
          <select
            id="accountType"
            className={`input ${errors.accountType ? 'border-red-500' : ''}`}
            {...register('accountType', { required: 'Please select an account type' })}
          >
            <option value="">Select an option</option>
            <option value="personal">Personal</option>
            <option value="business">Business</option>
            <option value="corporate">Corporate</option>
          </select>
          {errors.accountType && (
            <p className="error-message">
              <AlertCircle className="w-4 h-4 inline mr-1" />
              {errors.accountType.message}
            </p>
          )}
        </div>
      </div>

      <div>
        <label htmlFor="message" className="label">Message (Optional)</label>
        <textarea
          id="message"
          className="input h-32"
          placeholder="Tell us about your security needs or any specific concerns"
          {...register('message')}
        ></textarea>
      </div>

      <div className="flex items-start mb-4">
        <input
          type="checkbox"
          id="terms"
          className="mt-1"
          required
        />
        <label htmlFor="terms" className="ml-2 text-sm text-gray-600">
          I agree to YOURGUARD's <a href="#" className="text-primary-600 hover:underline">Terms of Service</a> and <a href="#" className="text-primary-600 hover:underline">Privacy Policy</a>
        </label>
      </div>

      <button
        type="submit"
        className="btn-primary w-full"
        disabled={isSubmitting}
      >
        {isSubmitting ? (
          <>
            <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
              <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
              <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
            </svg>
            Processing...
          </>
        ) : 'Get Started with YOURGUARD'}
      </button>

      <p className="text-center text-sm text-gray-500">
        Your information is secure. We never share your data with third parties.
      </p>
    </form>
  );
};

export default UserForm;