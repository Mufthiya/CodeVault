import React from 'react';
import Navbar from '../components/Navbar';
import Hero from '../components/Hero';
import Features from '../components/Features';
import HowItWorks from '../components/HowItWorks';
import Team from '../components/Team';
import UserForm from '../components/UserForm';
import Footer from '../components/Footer';

const Home: React.FC = () => {
  return (
    <div className="min-h-screen">
      <Navbar />
      <Hero />
      <Features />
      <HowItWorks />
      <Team />
      
      <section id="signup" className="section bg-white">
        <div className="container-custom">
          <div className="max-w-3xl mx-auto">
            <div className="text-center mb-12">
              <h2 className="mb-4 text-gray-900">Get Started with YOURGUARD</h2>
              <p className="text-xl text-gray-600">
                Fill out the form below to begin protecting your accounts with our AI-powered fraud detection
              </p>
            </div>
            
            <div className="bg-white rounded-xl shadow-card p-8">
              <UserForm />
            </div>
          </div>
        </div>
      </section>
      
      <Footer />
    </div>
  );
};

export default Home;