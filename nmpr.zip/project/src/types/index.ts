export interface UserFormData {
  fullName: string;
  email: string;
  phone: string;
  accountType: string;
  message?: string;
}

export interface NavItem {
  label: string;
  href: string;
}

export interface FeatureItem {
  title: string;
  description: string;
  icon: React.FC;
}

export interface TeamMember {
  name: string;
  role: string;
}